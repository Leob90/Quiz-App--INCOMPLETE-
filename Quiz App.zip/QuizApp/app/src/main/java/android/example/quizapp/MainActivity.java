package android.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    int results = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


        public void submitOrder(View view){
        //Get Text entry
        EditText nameField=(EditText) findViewById(R.id.name_field);
            Editable nameEditable=nameField.getText();
            String name = nameEditable.toString();

            //Checkbox 1
            CheckBox relativeCheckBox=(CheckBox) findViewById(R.id.relative_layout_checkbox);
            boolean relativeCheckBox=relativeCheckBox.isChecked();

            CheckBox linearCheckbox = (CheckBox) findViewById(R.id.linear_layout_checkbox);
            boolean linearCheckBox= linearCheckbox.isChecked();

            CheckBox constraintCheckBox = (CheckBox) findViewById(R.id.constraint_layout_checkbox);
            boolean constraintCheckBox = constraintCheckBox.isChecked();

            //Get Results of the quiz.
            @param relative_layout_checkbox
            @param linear_layout_checkbox
            @ return total price

            private int CalculatePrice(boolean relativeLayoutCheckBox, boolean linearLayoutCheckBox){
                //Calculate the price of coffee
                int baseScore = 0
                        //if the user checks on relative layout checkbox, add 0 to baseScore
                        if (relativeCheckBox) {
                            baseScore = baseScore + 0;
                        }
                        //If the user checks on linear layout checkbox, add 1 to baseScore
                        if (linearCheckBox) {
                            baseScore = baseScore + 1;
                        }
                        //If the user checks on constraint layout checkbox, add 0 to baseScore
                        if (constraintCheckBox) {
                            baseScore = baseScore +0;
                        }

                        //if the user checks the activity_main.xml button
                        if (onActivityButtonClicked) {
                            baseScore = baseScore + 0;
                        }

                        //if the user checks the MainActivity.java button
                        if (onMainActivityButtonClicked) {
                            baseScore = baseScore + 1;
                        }

                        //Get Results
                            return results * baseScore;
                        }
            }
    }
}